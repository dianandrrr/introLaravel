<html>
<head>
	<title>Halaman index</title>
</head>
<body>
	<h1>SanberBook</h1>
	<h2>Social Media Developer Santai Berkualitas</h2>
	<p>Belajar dan Berbagi agar hidup ini semakin santai berkualitas</p>
	<h2>Benefit Join di SanberBool</h2>
	<ul>
		<li>Mendapatkan Motivasi dari sesama developer</li>
		<li>Sharing Knowledge dari pada mastah sanber</li>
		<li>Dibuat oleh calon web developer terbaik</li>
	</ul>
	<h2>Cara Bergabung ke SanberBook</h2>
	<ol>
		<li>Mengunjungi Website ini</li>
		<li>Mendaftar di <a href="form.html">Form Sign up</a></li>
		<li>Selesai!</li>
	</ol>
</body>
</html>