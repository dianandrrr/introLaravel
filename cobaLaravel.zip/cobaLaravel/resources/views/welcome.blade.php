<html>
<head>
	<title>Welcome</title>
</head>
<body>
	<h1>SELAMAT DATANG! <?php echo ($_GET['fistName']." ".$_GET['lastName'])?></h1>
	<h3>Terima kasih telah bergabung di Sanberbook. Social Media kita bersama!</h3>
</body>
</html>